#!/usr/bin/env bash
cd ~/Downloads/Programs/recon-ng
./recon-ng
